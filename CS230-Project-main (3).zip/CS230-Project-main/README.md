# CS230-Project
**FaceNet.ipynb** Code to generate embeddings and compute accuracy.
**split_lfw_deepfunneled.py** Helper script to create Train/Val/Test images folders.
**generate_encodings.ipynb** Helper script.
